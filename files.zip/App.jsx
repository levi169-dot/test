import { useEffect, useState } from 'react'
import { Toaster, toast } from 'react-hot-toast'
import Header from './components/Header'
import PreviewCanvas from './components/PreviewCanvas'
import ConfigSidebar from './components/ConfigSidebar'
import { generate, DEFAULT_COLUMNS } from './lib/mock'

const wait = (ms) => new Promise((r) => setTimeout(r, ms))
const DEFAULT_SETTINGS = { rows: 100, seed: 42, nullRate: 5, outlierRate: 2, locale: 'en_US', currency: 'USD' }
const DEFAULT_RULES = [
  { id: 1, column: 'name', rule: 'mask' },
  { id: 2, column: 'email', rule: 'hash' },
  { id: 3, column: 'phone', rule: 'noise' },
]

export default function App() {
  const [dark, setDark] = useState(false)
  const [tab, setTab] = useState('tabular')
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [fileName, setFileName] = useState(null)
  const [settings, setSettings] = useState(DEFAULT_SETTINGS)
  const [rules, setRules] = useState(DEFAULT_RULES)
  const columns = data?.tabular.columns ?? DEFAULT_COLUMNS

  useEffect(() => { document.documentElement.classList.toggle('dark', dark) }, [dark])

  // ───────── Backend hooks: replace the bodies below with real API calls ─────────
  const runGeneration = async (s = settings, r = rules) => {
    setLoading(true)
    try {
      // TODO: const res = await api.post('/generate', { settings: s, rules: r, source: fileName })
      await wait(900)
      setData(generate(s, r))
      toast.success('Synthetic data generated')
    } catch {
      toast.error('Generation failed. Check your settings and try again.')
    } finally {
      setLoading(false)
    }
  }
  const handleRegenerate = () => runGeneration()
  const handleUpload = (file) => {
    // TODO: upload `file` (FormData) → infer schema → populate columns/rules
    setFileName(file.name)
    toast.success(`Uploaded ${file.name}`)
    runGeneration()
  }
  const handleUseExample = () => {
    // TODO: fetch example dataset + schema from the backend
    setFileName('example_customers.csv')
    setRules(DEFAULT_RULES)
    runGeneration(settings, DEFAULT_RULES)
  }
  const handleExport = (format) => {
    if (!data) return toast.error('Generate data before exporting')
    // TODO: request `${format}` export for the active dataset and trigger the download
    toast.success(`Exporting ${format}…`)
  }
  const handleSettings = () => toast('Settings panel not connected yet', { icon: '⚙️' }) // TODO: open settings modal
  // ─────────────────────────────────────────────────────────────────────────────

  const addRule = () =>
    setRules((r) => [...r, { id: Date.now(), column: columns.find((c) => !r.some((x) => x.column === c)) ?? columns[0], rule: 'mask' }])
  const updateRule = (id, patch) => setRules((r) => r.map((x) => (x.id === id ? { ...x, ...patch } : x)))
  const removeRule = (id) => setRules((r) => r.filter((x) => x.id !== id))

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 transition-colors duration-200 lg:flex lg:h-screen lg:flex-col dark:bg-slate-950 dark:text-slate-100">
      <Toaster
        position="top-right"
        toastOptions={{
          success: { iconTheme: { primary: '#10b981', secondary: '#fff' } },
          error: { iconTheme: { primary: '#ef4444', secondary: '#fff' } },
        }}
      />
      <Header dark={dark} onToggleDark={() => setDark((d) => !d)} onExport={handleExport} onSettings={handleSettings} />
      <main className="flex flex-1 flex-col gap-6 p-4 sm:p-6 lg:min-h-0 lg:flex-row">
        <section className="lg:w-[65%] lg:overflow-y-auto">
          <PreviewCanvas tab={tab} onTabChange={setTab} data={data} loading={loading} onUseExample={handleUseExample} />
        </section>
        <aside className="lg:min-h-0 lg:w-[35%]">
          <ConfigSidebar
            settings={settings} onSettingsChange={setSettings}
            rules={rules} columns={columns}
            onAddRule={addRule} onUpdateRule={updateRule} onRemoveRule={removeRule}
            onUpload={handleUpload} onUseExample={handleUseExample} onRegenerate={handleRegenerate}
            loading={loading} fileName={fileName}
          />
        </aside>
      </main>
    </div>
  )
}
