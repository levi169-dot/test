export default function DataTable({ columns, rows }) {
  return (
    <div className="animate-fade-in overflow-x-auto">
      <table className="w-full min-w-max text-left text-sm">
        <thead className="bg-slate-50 text-xs font-medium text-slate-500 dark:bg-slate-800/60 dark:text-slate-400">
          <tr>
            <th className="w-12 px-4 py-3 font-medium">#</th>
            {columns.map((c) => <th key={c} className="px-4 py-3 font-medium">{c}</th>)}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
          {rows.map((row, i) => (
            <tr key={i} className="transition-colors duration-200 ease-in-out hover:bg-indigo-50/50 dark:hover:bg-slate-800/50">
              <td className="px-4 py-2.5 text-slate-400">{i + 1}</td>
              {columns.map((c) => (
                <td key={c} className="whitespace-nowrap px-4 py-2.5 text-slate-700 dark:text-slate-200">
                  {row[c] ?? <span className="italic text-slate-400">NULL</span>}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
