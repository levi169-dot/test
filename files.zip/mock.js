// Seeded mock generator so the UI is fully demoable. Delete once the backend is wired up.
export const DEFAULT_COLUMNS = ['id', 'name', 'email', 'phone', 'amount', 'status']

const NAMES = ['Ava Chen', 'Liam Patel', 'Noah Khan', 'Mia Rossi', 'Zara Ahmed', 'Ethan Cole', 'Sofia Diaz', 'Omar Haddad']
const TITLES = ['Q3 Summary', 'Service Agreement', 'Purchase Order', 'Audit Notes', 'Onboarding Guide']
const rng = (s) => () => (s = (s * 1664525 + 1013904223) >>> 0) / 2 ** 32
const RULES = {
  mask: (v) => v[0] + '•'.repeat(6),
  hash: (v) => [...v].reduce((h, c) => (h * 31 + c.charCodeAt(0)) >>> 0, 7).toString(16).padStart(8, '0'),
  noise: (v, r) => v.replace(/\d/g, () => Math.floor(r() * 10)),
}
let version = 0

export function generate({ rows, seed, nullRate, outlierRate, currency }, rules = []) {
  const r = rng(seed >>> 0)
  const n = Math.min(rows, 25) // preview only
  const pick = (a) => a[Math.floor(r() * a.length)]
  const byCol = Object.fromEntries(rules.map((x) => [x.column, x.rule]))
  const cell = (col, v) => (r() * 100 < nullRate ? null : RULES[byCol[col]]?.(String(v), r) ?? v)
  const amount = () => `${currency} ${(r() * 100 < outlierRate ? 5e4 + r() * 5e4 : 20 + r() * 480).toFixed(2)}`
  const date = () => `2026-0${1 + Math.floor(r() * 9)}-${10 + Math.floor(r() * 18)}`
  const table = (columns, row, checks) => ({
    columns, total: rows, rows: Array.from({ length: n }, (_, i) => row(i + 1)),
    checks: checks.map((label) => ({ label, pass: true })),
  })

  return {
    version: ++version,
    tabular: table(DEFAULT_COLUMNS, (id) => {
      const name = pick(NAMES)
      return {
        id, name: cell('name', name), email: cell('email', `${name.toLowerCase().replace(' ', '.')}@example.com`),
        phone: cell('phone', `+1-555-${1000 + Math.floor(r() * 9000)}`), amount: cell('amount', amount()),
        status: pick(['active', 'pending', 'closed']),
      }
    }, ['Schema match', 'Privacy rules applied']),
    relational: table(['order_id', 'customer_id', 'total', 'placed_at'], (id) => ({
      order_id: 1000 + id, customer_id: 1 + Math.floor(r() * n), total: cell('total', amount()), placed_at: date(),
    }), ['FK integrity', 'Cardinality']),
    documents: table(['doc_id', 'title', 'type', 'words', 'created'], (id) => ({
      doc_id: `DOC-${String(id).padStart(4, '0')}`, title: pick(TITLES), type: pick(['Invoice', 'Contract', 'Report']),
      words: 200 + Math.floor(r() * 1800), created: date(),
    }), ['Schema match', 'Length distribution']),
  }
}
