import { CheckCircle2, DatabaseZap, FileText, Loader2, Network, Table2, XCircle } from 'lucide-react'
import DataTable from './DataTable'

const TABS = [['tabular', 'Tabular', Table2], ['relational', 'Relational', Network], ['documents', 'Documents', FileText]]

const Badge = ({ label, pass }) => (
  <span
    className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset ${
      pass
        ? 'bg-emerald-50 text-emerald-700 ring-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-400'
        : 'bg-red-50 text-red-700 ring-red-500/20 dark:bg-red-500/10 dark:text-red-400'
    }`}
  >
    {pass ? <CheckCircle2 size={14} /> : <XCircle size={14} />}
    {label}: {pass ? 'PASS' : 'FAIL'}
  </span>
)

const EmptyState = ({ onUseExample }) => (
  <div className="flex min-h-[440px] flex-col items-center justify-center px-6 text-center">
    <div className="mb-5 grid h-20 w-20 place-items-center rounded-2xl bg-indigo-50 ring-8 ring-indigo-50/60 dark:bg-indigo-500/10 dark:ring-indigo-500/5">
      <DatabaseZap size={36} className="text-indigo-600 dark:text-indigo-400" />
    </div>
    <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Upload data to get started</h3>
    <p className="mt-1 max-w-sm text-sm text-slate-500 dark:text-slate-400">
      Add a sample CSV and we'll infer its schema, or explore the workspace with example data.
    </p>
    <button
      onClick={onUseExample}
      className="mt-5 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white transition-all duration-200 ease-in-out hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:ring-offset-2 dark:focus:ring-offset-slate-900"
    >
      Use example data
    </button>
  </div>
)

export default function PreviewCanvas({ tab, onTabChange, data, loading, onUseExample }) {
  const ds = data?.[tab]

  return (
    <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <nav role="tablist" className="flex gap-1 border-b border-slate-200 px-3 dark:border-slate-800">
        {TABS.map(([id, label, Icon]) => (
          <button
            key={id} role="tab" aria-selected={tab === id} onClick={() => onTabChange(id)}
            className={`-mb-px flex items-center gap-2 border-b-2 px-4 py-3.5 text-sm font-medium transition-all duration-200 ease-in-out focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500/40 ${
              tab === id
                ? 'border-indigo-600 text-indigo-600 dark:border-indigo-400 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Icon size={16} />{label}
          </button>
        ))}
      </nav>

      <div className="relative min-h-[440px]">
        {ds ? (
          <>
            <div className="flex flex-wrap items-center gap-2 border-b border-slate-100 px-5 py-3 dark:border-slate-800">
              {ds.checks.map((c) => <Badge key={c.label} {...c} />)}
            </div>
            <DataTable key={`${data.version}-${tab}`} columns={ds.columns} rows={ds.rows} />
            <p className="border-t border-slate-100 px-5 py-3 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
              Showing {ds.rows.length} of {ds.total.toLocaleString()} rows
            </p>
          </>
        ) : (
          <EmptyState onUseExample={onUseExample} />
        )}

        <div
          aria-live="polite"
          className={`absolute inset-0 z-10 flex flex-col items-center justify-center gap-3 bg-white/70 backdrop-blur-sm transition-opacity duration-200 ease-in-out dark:bg-slate-900/70 ${
            loading ? 'opacity-100' : 'pointer-events-none opacity-0'
          }`}
        >
          <Loader2 size={36} className="animate-spin text-indigo-600 dark:text-indigo-400" />
          <p className="text-sm font-medium text-slate-600 dark:text-slate-300">Generating synthetic data…</p>
        </div>
      </div>
    </div>
  )
}
