import { useEffect, useRef, useState } from 'react'
import { Braces, ChevronDown, Database, Download, FileText, FileType, Moon, Settings, Sun } from 'lucide-react'

const FORMATS = [['CSV', FileText], ['JSON', Braces], ['PDF', FileType]]
const btn =
  'inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 transition-all duration-200 ease-in-out hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700'

export default function Header({ dark, onToggleDark, onExport, onSettings }) {
  const [open, setOpen] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    const close = (e) => !ref.current?.contains(e.target) && setOpen(false)
    document.addEventListener('mousedown', close)
    return () => document.removeEventListener('mousedown', close)
  }, [])

  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur dark:border-slate-800 dark:bg-slate-900/90">
      <div className="flex h-16 items-center justify-between px-4 sm:px-6">
        <div className="flex items-center gap-3">
          <div className="grid h-9 w-9 place-items-center rounded-lg bg-indigo-600 text-white"><Database size={18} /></div>
          <div>
            <h1 className="text-base font-semibold text-slate-900 dark:text-white">Synthetic Data Platform</h1>
            <p className="hidden text-xs text-slate-500 sm:block dark:text-slate-400">Schema-aware data generation</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button onClick={onToggleDark} aria-label="Toggle dark mode" className={`${btn} px-2.5`}>
            {dark ? <Sun size={16} /> : <Moon size={16} />}
          </button>

          <div ref={ref} className="relative">
            <button onClick={() => setOpen((o) => !o)} aria-haspopup="menu" aria-expanded={open} className={btn}>
              <Download size={16} />
              <span className="hidden sm:inline">Export</span>
              <ChevronDown size={14} className={`transition-transform duration-200 ${open ? 'rotate-180' : ''}`} />
            </button>
            <div
              role="menu"
              className={`absolute right-0 mt-2 w-40 origin-top-right rounded-xl border border-slate-200 bg-white p-1 shadow-lg transition-all duration-200 ease-in-out dark:border-slate-700 dark:bg-slate-800 ${
                open ? 'scale-100 opacity-100' : 'pointer-events-none scale-95 opacity-0'
              }`}
            >
              {FORMATS.map(([format, Icon]) => (
                <button
                  key={format} role="menuitem"
                  onClick={() => { setOpen(false); onExport(format) }}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-slate-700 transition-colors duration-200 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-700"
                >
                  <Icon size={16} className="text-slate-400" />{format}
                </button>
              ))}
            </div>
          </div>

          <button onClick={onSettings} className={btn}>
            <Settings size={16} /><span className="hidden sm:inline">Settings</span>
          </button>
        </div>
      </div>
    </header>
  )
}
