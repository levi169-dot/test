import { useRef } from 'react'
import { FileSpreadsheet, Plus, RefreshCw, ShieldCheck, SlidersHorizontal, Sparkles, Trash2, Upload } from 'lucide-react'

const ctl =
  'w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 transition-all duration-200 ease-in-out focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100'
const primary =
  'flex items-center justify-center gap-2 rounded-lg bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition-all duration-200 ease-in-out hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-70 dark:focus:ring-offset-slate-900'
const secondary =
  'flex items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition-all duration-200 ease-in-out hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700'

const RULE_OPTIONS = [['mask', 'Mask'], ['hash', 'Hash'], ['noise', 'Noise'], ['keep', 'Keep']]
const LOCALES = ['en_US', 'en_GB', 'de_DE', 'fr_FR', 'ja_JP', 'ur_PK']
const CURRENCIES = ['USD', 'EUR', 'GBP', 'JPY', 'PKR']

const Card = ({ icon: Icon, title, children }) => (
  <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
    <h2 className="mb-4 flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
      <Icon size={16} className="text-indigo-600 dark:text-indigo-400" />{title}
    </h2>
    {children}
  </section>
)
const Field = ({ label, hint, children }) => (
  <label className="block">
    <span className="mb-1.5 flex justify-between text-xs font-medium text-slate-500 dark:text-slate-400">{label}<span>{hint}</span></span>
    {children}
  </label>
)
const Select = ({ options, ...props }) => (
  <select className={ctl} {...props}>
    {options.map((o) => {
      const [value, label] = Array.isArray(o) ? o : [o, o]
      return <option key={value} value={value}>{label}</option>
    })}
  </select>
)
const Slider = ({ label, max, value, onChange }) => (
  <Field label={label} hint={`${value}%`}>
    <input type="range" min={0} max={max} value={value} onChange={onChange} className="w-full cursor-pointer accent-indigo-600" />
  </Field>
)

export default function ConfigSidebar({
  settings, onSettingsChange, rules, columns, onAddRule, onUpdateRule, onRemoveRule,
  onUpload, onUseExample, onRegenerate, loading, fileName,
}) {
  const fileRef = useRef(null)
  const set = (key, numeric) => (e) => onSettingsChange({ ...settings, [key]: numeric ? Number(e.target.value) : e.target.value })

  return (
    <div className="flex flex-col gap-4 lg:h-full lg:min-h-0">
      <div className="space-y-4 lg:min-h-0 lg:flex-1 lg:overflow-y-auto lg:pr-1">
        <Card icon={FileSpreadsheet} title="Data source">
          <input
            ref={fileRef} type="file" accept=".csv" hidden
            onChange={(e) => { const f = e.target.files[0]; if (f) onUpload(f); e.target.value = '' }}
          />
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
            <button onClick={() => fileRef.current.click()} className={primary}><Upload size={16} />Upload sample CSV</button>
            <button onClick={onUseExample} className={secondary}><Sparkles size={16} />Use example data</button>
          </div>
          {fileName && (
            <p className="mt-3 truncate text-xs text-slate-500 dark:text-slate-400">
              Source: <span className="font-medium text-slate-700 dark:text-slate-300">{fileName}</span>
            </p>
          )}
        </Card>

        <Card icon={SlidersHorizontal} title="Generation settings">
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <Field label="Row count">
                <input type="number" min={1} max={1000000} className={ctl} value={settings.rows} onChange={set('rows', true)} />
              </Field>
              <Field label="Seed">
                <input type="number" className={ctl} value={settings.seed} onChange={set('seed', true)} />
              </Field>
            </div>
            <Slider label="Null rate" max={50} value={settings.nullRate} onChange={set('nullRate', true)} />
            <Slider label="Outlier rate" max={25} value={settings.outlierRate} onChange={set('outlierRate', true)} />
            <div className="grid grid-cols-2 gap-3">
              <Field label="Locale"><Select options={LOCALES} value={settings.locale} onChange={set('locale')} /></Field>
              <Field label="Currency"><Select options={CURRENCIES} value={settings.currency} onChange={set('currency')} /></Field>
            </div>
          </div>
        </Card>

        <Card icon={ShieldCheck} title="Privacy rules">
          <div className="space-y-2">
            {rules.map((r) => (
              <div key={r.id} className="flex items-center gap-2">
                <Select aria-label="Column" options={columns} value={r.column} onChange={(e) => onUpdateRule(r.id, { column: e.target.value })} />
                <span className="text-slate-400" aria-hidden>→</span>
                <Select aria-label="Rule" options={RULE_OPTIONS} value={r.rule} onChange={(e) => onUpdateRule(r.id, { rule: e.target.value })} />
                <button
                  onClick={() => onRemoveRule(r.id)} aria-label="Remove rule"
                  className="rounded-lg p-2 text-slate-400 transition-all duration-200 ease-in-out hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-500/10"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))}
            {!rules.length && <p className="py-2 text-center text-xs text-slate-500">No rules yet. All columns are generated as-is.</p>}
          </div>
          <button
            onClick={onAddRule}
            className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-lg border border-dashed border-slate-300 py-2 text-sm font-medium text-slate-600 transition-all duration-200 ease-in-out hover:border-indigo-500 hover:text-indigo-600 dark:border-slate-700 dark:text-slate-400 dark:hover:border-indigo-400 dark:hover:text-indigo-400"
          >
            <Plus size={16} />Add rule
          </button>
        </Card>
      </div>

      <button onClick={onRegenerate} disabled={loading} className={`${primary} w-full shrink-0 rounded-xl py-3`}>
        <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
        {loading ? 'Generating…' : 'Regenerate data'}
      </button>
    </div>
  )
}
